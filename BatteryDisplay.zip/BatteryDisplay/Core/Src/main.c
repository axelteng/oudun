/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "TO485.h"
#include "KEYREMOTESENSE.h"
#include <stdio.h>
#include "OLED_I2C.h"
#include "stdlib.h"
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t CAN_Rx_Buffer[8] = {0};       // 接收数据缓冲区
uint8_t CanRxReceive[dataAll] = {0}; 		// Define the data of a global variable without CRC
uint8_t CanRxReceiveSpeed[dataAll*2+3*4] = {0}; 		// Define the speed data of a global variable without CRC
//uint8_t dataORspeed = SPEED;	// data OR speed
float tmep;
volatile uint8_t CAN_Data_Ready = 0;  // 数据就绪标志

volatile uint8_t sys_1ms_Flag = 0;   // 1ms 标志
volatile uint8_t sys_10ms_Flag = 0;  // 10ms 标志 (给摇杆用)
volatile uint8_t sys_700ms_Flag = 0; // 700ms 标志 (给 PA0 用)

#define   DelaySendTime   1000
uint8_t tempTest = 0;   // 用于按键消抖检测
uint8_t tempNum = 0;    // 用于记录按键状态 (0=关闭, 1=开启)

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
		 
	int num = 0,tempnum = 0;
	char sting[50] = {0};
	static uint8_t sendLocation = 0;   // 发送水平和垂直坐标
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
	
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_Base_Start_IT(&htim2);
//	Remote_Calibrate();
	OLED_Init();
	OLED_CLS();
	// uint8_t dir = 0;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1){ 
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

//		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_RESET);
//		HAL_Delay(1000);
//		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_SET);
//		HAL_Delay(1000);

		sendRS485AndCRC(); 
    uint8_t ret = RS485_ReceiveBattery();
		
		switch(ret){
			case 0:
				printf("HEX: ");
				for (uint8_t i = 0; i < rxHexLen; i++)		printf("%02X ", rxHex[i]);
				printf("\r\nDEC: ");
				for (uint8_t i = 0; i < rxDecLen; i++)		printf("%u ", rxDec[i]);
				printf("\r\n");				
			break;
			case 1:		printf("超时无回复\r\n");			break;
			case 2:		printf("帧错\r\n");						break;			
			case 3:		printf("CRC错\r\n");					break;
			default:	printf("未知错误 ret=%d\r\n", ret);		break;
		}

		
		
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    static uint16_t cnt = 0;
    if(htim->Instance == TIM2) // 确保是 TIM2
    {
        cnt++;
        sys_1ms_Flag = 1; // 每1ms置位
        
        if(cnt % 10 == 0) sys_10ms_Flag = 1; // 每10ms置位 (摇杆频率够用了)
        if(cnt % DelaySendTime == 0) sys_700ms_Flag = 1; // 每700ms置位
        
        if(cnt >= DelaySendTime) cnt = 0; // 防溢出
    }
}
int fputc(int ch, FILE *f){
    HAL_UART_Transmit(&huart2, (uint8_t*)&ch, 1, 100);
    return ch;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
